=== WP-Polls ===
Contributors: GamerZ
Donate link: http://lesterchan.net/wordpress
Tags: poll, polls, polling, vote, booth, democracy, ajax, survey, post, widget
Requires at least: 2.8
Stable tag: 2.50

Adds an AJAX poll system to your WordPress blog. You can also easily add a poll into your WordPress's blog post/page.

== Description ==
WP-Polls is extremely customizable via templates and css styles and there are tons of options for you to choose to ensure that WP-Polls runs the way you wanted. It now supports multiple selection of answers.

All the information (general, changelog, installation, upgrade, usage) you need about this plugin can be found here: [WP-Polls Readme](http://lesterchan.net/wordpress/readme/wp-polls.html "WP-Polls Readme").
It is the exact same readme.html is included in the zip package.

== Development Blog ==

[GaMerZ WordPress Plugins Development Blog](http://lesterchan.net/wordpress/ "GaMerZ WordPress Plugins Development Blog")

== Installation ==

[WP-Polls Readme](http://lesterchan.net/wordpress/readme/wp-polls.html "WP-Polls Readme") (Installation Tab)

== Screenshots ==

[WP-Polls Screenshots](http://lesterchan.net/wordpress/screenshots/browse/wp-polls/ "WP-Polls Screenshots")

== Frequently Asked Questions ==

[WP-Polls Support Forums](http://forums.lesterchan.net/index.php?board=15.0 "WP-Polls Support Forums")